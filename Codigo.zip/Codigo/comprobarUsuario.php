<?php
	$user = $_REQUEST["user"];
	if ($user === "pablo")
		echo "existe";
	else
		echo "disponible";
?>