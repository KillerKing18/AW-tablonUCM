$(document).ready(function() {
	$("#correoOK").hide();
	$("#userOK").hide();

	$("#campoEmail").on("input", function(){
		$("#correoOK").show();
		const campo = $("#campoEmail");
		campo[0].setCustomValidity("");

		const esCorreoValido = campo[0].checkValidity();
		if (esCorreoValido && correoValidoComplu(campo.val())) {
			$("#correoOK").html("&#x2714");
			campo[0].setCustomValidity("");
		} else {	
			$("#correoOK").html("&#x26a0");		
			campo[0].setCustomValidity("El correo debe ser válido y acabar por @ucm.es");
		}
	});

	
	$("#campoUser").on("input", function() {
		$("#userOK").show();
		$("#campoUser")[0].setCustomValidity("");
		var url = "comprobarUsuario.php?user=" + $("#campoUser").val();
		$.get(url, usuarioExiste);
	});


	function correoValidoComplu(correo) {
		return correo.substr(-7) === "@ucm.es";
	}

	function usuarioExiste(data, status) {
		if(data === "existe"){
			$("#userOK").html("&#x26a0");	
			$("#campoUser")[0].setCustomValidity("Ese usuario ya existe");
		}
		else if (data === "disponible")
			$("#userOK").html("&#x2714");
	}
});